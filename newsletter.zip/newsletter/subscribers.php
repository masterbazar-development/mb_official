<?php
require '../database.php';

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    // Email Validtions
    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {

        // Insert the email into the database
        $sql = "INSERT INTO mb_subscribers (user_email, submit_date) VALUES ('$email', NOW())";
        if ($conn->query($sql) === TRUE) {
            echo "Subscription successful!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Invalid email address";
    }
}


$conn->close();
?>