# Animated Morphing Gradients Background

CSS Animations + SVG Effects

Video with implementation details: https://www.youtube.com/watch?v=Ml-B-W91gtw&lc=UgxNljgqkl2YkrP2WS14AaABAg&ab_channel=WeCoded

<img width="1728" alt="Screenshot 2023-07-09 at 10 57 29" src="https://github.com/baunov/gradients-bg/assets/54023692/5edaccf7-8ad5-468d-b4b5-4c18ee2fe32e">
